def insert_data():
    # read csv file
    # use faker to generate first name last name
    # generate password, use werkzeug to hash password
    pass
